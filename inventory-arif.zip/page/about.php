<div class="jumbotron bg-light shadow text-center">
    <h1 class="display-3">Inventory Online</h1>
    <p class="lead text-monoscope">Inventory app versi 1.0</p>
    <hr class="my-4">
    <p>Mas Sahal - Cirebon, 10 Agustus 2020 - Yogyakarta </p>
    <i></i>
    <a class="btn btn-outline-success btn-lg" href="?page=inventory" role="button">Mulai </a>
    <div class="row">
        <div class="col text-right"><?=$tanggal; ?></div>
    </div>
</div>