<div class="jumbotron bg-light shadow">
    <h1 class="display-4">Hi, Admin!</h1>
    <p class="lead">Selamat Datang Di Aplikasi Inventory Online.</p>
    <hr class="my-4">
    <p>Ini adalah aplikasi inventory produk berbasis web dengan desain yang elegan dan flat.</p>
    <a class="btn btn-info btn-lg" href="?page=inventory" role="button">Mulai tindakan</a>
    <div class="row">
        <div class="col text-right"><?=$tanggal; ?></div>
    </div>
</div>
