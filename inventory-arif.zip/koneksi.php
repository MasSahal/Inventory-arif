<?php
    $koneksi = new mysqli('localhost','root','','inventory-arif');
?>